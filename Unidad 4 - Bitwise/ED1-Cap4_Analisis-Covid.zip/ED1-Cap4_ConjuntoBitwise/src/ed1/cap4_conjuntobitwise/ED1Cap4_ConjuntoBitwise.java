
package ed1.cap4_conjuntobitwise;

import Negocio.ConjuntoBtw;
import Negocio.ConjuntoDinamicoBtw;
import Negocio.ConjuntoRangoBtw;

public class ED1Cap4_ConjuntoBitwise {

    public static void main(String[] args) {
        ConjuntoDinamicoBtw cb = new ConjuntoDinamicoBtw();
        
        cb.insertar(2);
        cb.insertar(10);
        cb.insertar(28);
        cb.insertar(32);
        cb.insertar(52);
        cb.insertar(64);

        System.out.println(cb.toString());
        System.out.println("cantidad de elementos: "+cb.cant);
        System.out.println("cantidad de Bitwise: "+cb.cantBitwise());
        
        cb.eliminar(64);
        System.out.println(cb.toString());
        System.out.println("cantidad de elementos: "+cb.cant);
        System.out.println("cantidad de Bitwise: "+cb.cantBitwise());
        
    }
    
}
