
package ed1.cap4_fraccionbits;

import Negocio.FraccionBits;

public class ED1Cap4_FraccionBits {


    public static void main(String[] args) {
        FraccionBits f1 = new FraccionBits('-', 9, 5);
        System.out.println("F1:\n"+f1);

        FraccionBits f2 = new FraccionBits('+', 10, 5);
        System.out.println("F2:\n"+f2);
        
        FraccionBits f3 = new FraccionBits();
        f3.Dividir(f1, f2);
        System.out.println("f3:\n"+f3);
    }
    
}
