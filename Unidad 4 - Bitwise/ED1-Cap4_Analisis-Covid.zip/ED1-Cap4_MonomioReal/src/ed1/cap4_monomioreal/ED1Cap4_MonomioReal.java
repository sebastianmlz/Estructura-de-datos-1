
package ed1.cap4_monomioreal;

import Negocio.MonomioRealBits;


public class ED1Cap4_MonomioReal {


    public static void main(String[] args) {
        MonomioRealBits m1 = new MonomioRealBits('-', 5, 2, 10, 4);
        System.out.println(m1.toString2());
        
        MonomioRealBits m2 = new MonomioRealBits('-', 10, 2, 10, 4);
        System.out.println(m2.toString2());
        
        MonomioRealBits m3 = new MonomioRealBits();
        m3.Sumar(m1, m2);
        System.out.println(m3.toString2());
    }
    
}
