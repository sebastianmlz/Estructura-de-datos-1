
package ed1.cap4_polinomiobits;

import Negocio.Monomio_NBits;
import Negocio.PolinomioBits;

public class ED1Cap4_PolinomioBits {

    public static void main(String[] args) {
        PolinomioBits p = new PolinomioBits(2);
        Monomio_NBits B = new Monomio_NBits('-', 5, 8);
        p.insertar(B);
        Monomio_NBits C = new Monomio_NBits('+', 3, 7);
        p.insertar(C);
        System.out.println("P = " + p.toString());
        
        PolinomioBits Q = new PolinomioBits(4);
        Monomio_NBits B1 = new Monomio_NBits('+', 5, 2);
        Q.insertar(B1);
        Monomio_NBits C1 = new Monomio_NBits('+', 1, 4);
        Q.insertar(C1);
        System.out.println("Q = "+Q.toString());
        PolinomioBits R = new PolinomioBits();
        R.multiplicar(p, Q);
        System.out.println("R = "+R.toString());
    }
    
}
