
package ed1.cap4_tda.fecha.bits;

import Negocio.FechaBits;

public class ED1Cap4_TDAFechaBits {


    public static void main(String[] args) {
        FechaBits f = new FechaBits(10);
        
        f.insertarf2(28, 2, 2004, 2);
        f.insertarf2(30, 2, 2003, 1);
        f.insertarf2(23, 6, 2004, 3);

        
        System.out.println(f);

    }
    
}
