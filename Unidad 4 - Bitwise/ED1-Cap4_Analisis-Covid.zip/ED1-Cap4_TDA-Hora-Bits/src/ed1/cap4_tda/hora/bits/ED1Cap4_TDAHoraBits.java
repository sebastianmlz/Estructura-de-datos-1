
package ed1.cap4_tda.hora.bits;

import Negocio.HoraBits;

public class ED1Cap4_TDAHoraBits {


    public static void main(String[] args) {
        HoraBits h = new HoraBits(10);
        
        h.insertar(11, 11, 0, 1);
        h.insertar(6, 50, 59, 3);
        h.insertar(24, 3, 44, 2);
        
        System.out.println(h);
        
    }
    
}
